#pip install python-docx
#pip install pywin32
#pip install pywinauto
#pip install webdriver-manager
#pip install lxml
#pip install html_parser

네이버카페 점검중이면 마우스 좌표 달라져서 불가능, 포멧 변경시에도 불가능

